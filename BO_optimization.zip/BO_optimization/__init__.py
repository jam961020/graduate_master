"""
Bayesian Optimization for Welding Line Detection
"""
__version__ = "1.0.0"